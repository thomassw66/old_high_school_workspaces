
public class GPSILoveYou {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}
	int roads [][];
	public static int roadsForced(int roadNumber){
		
		return 0;
	}
}
