import java.awt.Point;
import java.awt.geom.*;

public class Temo {

	public static void main(String [] aargg){
		
	}
}
