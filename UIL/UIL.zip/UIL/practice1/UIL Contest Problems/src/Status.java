
public class Status {
	public static void main(String [] welcome){
		for(int i = 0 ; i < 10; i++){
			System.out.println("WELCOME TO THE UIL DISTRICT CONTEST");
		}
	}
}
